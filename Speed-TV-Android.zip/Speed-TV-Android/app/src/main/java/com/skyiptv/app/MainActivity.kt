package com.skyiptv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private data class Channel(val name: String, val url: String, val logo: String = "")
private val categories = listOf("الكل", "رياضة", "عراقية", "MBC", "أفلام", "ترفيه", "إخبارية")

private val Navy = Color(0xFF050F1C)
private val Card = Color(0xFF0B1B2C)
private val Blue = Color(0xFF18A8FF)
private val Muted = Color(0xFF8EA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpeedTvApp() }
    }
}

@Composable
private fun SpeedTvApp() {
    val context = LocalContext.current
    val allChannels = remember { loadChannels(context) }
    var selected by remember { mutableStateOf<Channel?>(null) }
    var tab by remember { mutableStateOf(0) }
    var category by remember { mutableStateOf("الكل") }
    var search by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<String>() }

    val visible = allChannels.filter { c ->
        val categoryOk = categoryMatches(c, category)
        val searchOk = search.isBlank() || c.name.contains(search, true)
        val favoriteOk = tab != 2 || favorites.contains(c.name)
        categoryOk && searchOk && favoriteOk
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Card)) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = Navy) {
                if (selected != null) {
                    PlayerScreen(selected!!) { selected = null }
                } else {
                    HomeScreen(
                        channels = visible,
                        total = allChannels.size,
                        category = category,
                        search = search,
                        tab = tab,
                        favorites = favorites,
                        onTab = { tab = it },
                        onCategory = { category = it; tab = 0 },
                        onSearch = { search = it },
                        onPlay = { selected = it },
                        onFavorite = { c -> if (favorites.contains(c.name)) favorites.remove(c.name) else favorites.add(c.name) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    channels: List<Channel>, total: Int, category: String, search: String, tab: Int,
    favorites: List<String>, onTab: (Int) -> Unit, onCategory: (String) -> Unit,
    onSearch: (String) -> Unit, onPlay: (Channel) -> Unit, onFavorite: (Channel) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Brand()
                Spacer(Modifier.weight(1f))
                Text("⌕", color = Color.White, fontSize = 30.sp)
            }
            Spacer(Modifier.height(14.dp))
            HeroCard()
            Spacer(Modifier.height(14.dp))
            Text("التصنيفات", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.height(94.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories.take(4)) { c -> CategoryCard(c, c == category) { onCategory(c) } }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(if (tab == 2) "المفضلة" else "القنوات المتاحة", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("$total قناة", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = search,
                onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("ابحث عن قناة", color = Muted) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF1D3348), focusedTextColor = Color.White, unfocusedTextColor = Color.White)
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 10.dp), modifier = Modifier.fillMaxSize()) {
                items(channels) { c -> ChannelRow(c, favorites.contains(c.name), onFavorite, onPlay) }
                if (channels.isEmpty()) item { EmptyState() }
            }
        }
        BottomNav(tab, onTab)
    }
}

@Composable private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Blue, Color(0xFF0068D9))), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text("▶", color = Color.White, fontSize = 22.sp)
        }
        Spacer(Modifier.width(9.dp))
        Text("Speed", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(" TV", color = Blue, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun HeroCard() {
    Box(Modifier.fillMaxWidth().height(166.dp).background(Brush.horizontalGradient(listOf(Color(0xFF0C4E83), Color(0xFF071322))), RoundedCornerShape(20.dp)).padding(18.dp)) {
        Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            Text("مباشر الآن", color = Color(0xFF56C5FF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Speed TV", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("قنواتك المفضلة في مكان واحد", color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            Surface(color = Blue, shape = RoundedCornerShape(12.dp)) { Text("شاهد الآن", color = Color.White, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable private fun CategoryCard(name: String, selected: Boolean, click: () -> Unit) {
    Surface(color = if (selected) Color(0xFF126FA8) else Card, shape = RoundedCornerShape(14.dp), modifier = Modifier.clickable { click() }) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(categoryIcon(name), fontSize = 22.sp)
            Text(name, color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable private fun ChannelRow(c: Channel, fav: Boolean, onFavorite: (Channel) -> Unit, play: (Channel) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(15.dp)).clickable { play(c) }.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).background(Color(0xFF13283C), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(channelBadge(c.name), color = Blue, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(displayName(c.name), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(Color(0xFFFF3B30), RoundedCornerShape(50)))
                Spacer(Modifier.width(5.dp))
                Text("مباشر الآن", color = Blue, fontSize = 12.sp)
            }
        }
        Text(if (fav) "♥" else "♡", color = if (fav) Color(0xFFFF4F68) else Color.White, fontSize = 27.sp, modifier = Modifier.clickable { onFavorite(c) })
    }
}

@Composable private fun BottomNav(tab: Int, onTab: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF071421)).padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceAround) {
        NavItem("⌂", "الرئيسية", tab == 0) { onTab(0) }
        NavItem("▣", "مباشر", tab == 1) { onTab(1) }
        NavItem("♥", "المفضلة", tab == 2) { onTab(2) }
        NavItem("⌕", "البحث", tab == 3) { onTab(3) }
        NavItem("⚙", "الإعدادات", tab == 4) { onTab(4) }
    }
}

@Composable private fun NavItem(icon: String, label: String, active: Boolean, click: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { click() }.padding(horizontal = 7.dp)) {
        Text(icon, color = if (active) Blue else Color(0xFF8B9AAC), fontSize = 21.sp)
        Text(label, color = if (active) Blue else Color(0xFF8B9AAC), fontSize = 10.sp)
    }
}

@Composable private fun EmptyState() {
    Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { Text("لا توجد قنوات مطابقة", color = Muted, fontSize = 15.sp) }
}

@Composable private fun PlayerScreen(channel: Channel, back: () -> Unit) {
    val context = LocalContext.current
    val player = remember(channel.url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(channel.url)); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", color = Color.White, fontSize = 38.sp, modifier = Modifier.clickable { back() })
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) { Text(displayName(channel.name), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("مباشر", color = Color(0xFFFF3B30), fontSize = 12.sp) }
        }
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Text("Speed TV • البث المباشر", color = Color.White, modifier = Modifier.padding(16.dp), fontSize = 14.sp)
    }
}

private fun categoryIcon(name: String) = when (name) { "رياضة" -> "⚽"; "عراقية" -> "🇮🇶"; "MBC" -> "MBC"; "أفلام" -> "🎬"; else -> "📺" }
private fun channelBadge(n: String) = when { n.contains("Bein", true) -> "beIN\nSPORTS"; n.contains("MBC", true) -> "MBC"; n.contains("SSC", true) -> "SSC"; n.contains("SHARQYIA", true) -> "الشرقية"; n.contains("IRAQYIA", true) -> "العراقية"; else -> "TV" }
private fun displayName(n: String) = n.replace('-', ' ')
private fun categoryMatches(c: Channel, cat: String) = when (cat) {
    "رياضة" -> listOf("Bein", "SPORT", "AD-SPORT", "SSC", "Al-Kass").any { c.name.contains(it, true) }
    "عراقية" -> listOf("SHARQYIA", "SUMRYIA", "BAGHDAD", "IRAQYIA").any { c.name.contains(it, true) }
    "MBC" -> c.name.startsWith("MBC", true)
    "أفلام" -> listOf("MOVIES", "Film", "Showcase", "OSN-MAZZE").any { c.name.contains(it, true) }
    "ترفيه" -> listOf("MTV", "TLC", "OSN-LIVING").any { c.name.contains(it, true) }
    "إخبارية" -> listOf("NEWS", "IRAQYIA-NEWS", "SHARQYIA-NEWS").any { c.name.contains(it, true) }
    else -> true
}

private fun loadChannels(context: android.content.Context): List<Channel> {
    val text = context.resources.openRawResource(com.skyiptv.app.R.raw.channels).bufferedReader().use { it.readText() }
    val lines = text.lines(); val out = mutableListOf<Channel>(); var name = ""
    for (line in lines) {
        when {
            line.startsWith("#EXTINF") -> name = line.substringAfterLast(',').trim()
            line.isNotBlank() && !line.startsWith("#") -> if (name.isNotBlank()) { out.add(Channel(name, line.trim())); name = "" }
        }
    }
    return out.distinctBy { it.name + it.url }
}
